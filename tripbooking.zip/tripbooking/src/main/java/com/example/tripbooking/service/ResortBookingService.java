package com.example.tripbooking.service;
public interface ResortBookingService {
    void processBooking(String name, String emailId, String roomType, String checkIn, String checkOut);
}
